<div class="bg-card-bg rounded-3xl p-6 border border-bor-color shadow-custom">
     <h3 class="text-lg font-bold text-gray-900 dark:text-white mb-6 border-b border-bor-color pb-4">
        <?php echo e(__('messages.khmer_details')); ?>

    </h3>
     <div class="space-y-6">
        <div>
            <label class="block text-sm font-semibold mb-2 text-gray-700 dark:text-gray-300"><?php echo e(__('messages.shop_name_kh')); ?></label>
            <input type="text" name="shop_kh" value="<?php echo e(old('shop_kh', $shop->shop_kh ?? '')); ?>"
                class="w-full px-4 py-3 rounded-xl border border-input-border bg-input-bg text-gray-900 dark:text-white focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all font-khmer placeholder-gray-400">
        </div>
        <div>
            <label class="block text-sm font-semibold mb-2 text-gray-700 dark:text-gray-300"><?php echo e(__('messages.address_kh')); ?></label>
            <textarea name="address_kh" rows="2" 
                class="w-full px-4 py-3 rounded-xl border border-input-border bg-input-bg text-gray-900 dark:text-white focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all font-khmer placeholder-gray-400"><?php echo e(old('address_kh', $shop->address_kh ?? '')); ?></textarea>
        </div>
        <div>
            <label class="block text-sm font-semibold mb-2 text-gray-700 dark:text-gray-300"><?php echo e(__('messages.description_kh')); ?></label>
            <textarea name="description_kh" rows="3" 
                class="w-full px-4 py-3 rounded-xl border border-input-border bg-input-bg text-gray-900 dark:text-white focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all font-khmer placeholder-gray-400"><?php echo e(old('description_kh', $shop->description_kh ?? '')); ?></textarea>
        </div>
        <div>
            <label class="block text-sm font-semibold mb-2 text-gray-700 dark:text-gray-300"><?php echo e(__('messages.note_kh')); ?></label>
            <textarea name="note_kh" rows="3" 
                class="w-full px-4 py-3 rounded-xl border border-input-border bg-input-bg text-gray-900 dark:text-white focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all font-khmer placeholder-gray-400"><?php echo e(old('note_kh', $shop->note_kh ?? '')); ?></textarea>
        </div>
     </div>
</div><?php /**PATH C:\ZYNX\mikeav2\sale_mi\resources\views/admin/shop_info/partials/khmer_details.blade.php ENDPATH**/ ?>