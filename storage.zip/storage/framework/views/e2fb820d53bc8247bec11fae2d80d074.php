<div class="bg-card-bg border border-border-color rounded-2xl p-6 shadow-custom transition-all duration-300">
    <h3 class="font-bold text-lg mb-6 flex items-center gap-3 text-gray-800 dark:text-white pb-4 border-b border-border-color">
        <span class="p-2 rounded-lg bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400">
            <i class="ri-flag-fill"></i>
        </span>
        <?php echo e(__('messages.brand_identity')); ?>

    </h3>

    <?php echo $__env->make('components.color-input', ['label' => __('messages.col_primary_bg'), 'key' => 'primary'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('components.color-input', ['label' => __('messages.col_primary_text'), 'key' => 'primaryText'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('components.color-input', ['label' => __('messages.col_general_text'), 'key' => 'textColor'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('components.color-input', ['label' => __('messages.col_secondary'), 'key' => 'secondary'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div><?php /**PATH C:\ZYNX\mikeav2\sale_mi\resources\views/admin/theme/brand_identity.blade.php ENDPATH**/ ?>