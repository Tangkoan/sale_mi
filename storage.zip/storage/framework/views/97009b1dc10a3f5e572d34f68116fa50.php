<div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-4 md:mb-6 gap-4">
    
    <div class="flex justify-between items-center w-full md:w-auto">
        <h1 class="text-xl md:text-2xl font-black text-sidebar-text tracking-tight">
            <?php echo e(__('messages.sale_report')); ?>

        </h1>
        <button onclick="triggerReset()" class="md:hidden p-2 rounded-full bg-input-bg text-sidebar-text active:bg-bor-color border border-bor-color">
            <i class="ri-refresh-line text-lg"></i>
        </button>
    </div>
    
    
    <div class="w-full md:w-auto bg-card-bg p-2 rounded-xl shadow-custom border border-bor-color flex flex-col md:flex-row gap-3 md:gap-2">
        
        
        <div class="flex  p-1  w-full md:w-auto relative  ">
            
            
            <div class="flex gap-2">
                <button onclick="exportReport('excel')" class="flex items-center gap-1 bg-green-600 hover:bg-green-700 text-white px-3 py-1.5 rounded-lg text-xs font-bold shadow-sm transition-colors">
                    <i class="ri-file-excel-line"></i> Excel
                </button>
                <button onclick="exportReport('pdf')" class="flex items-center gap-1 bg-red-600 hover:bg-red-700 text-white px-3 py-1.5 rounded-lg text-xs font-bold shadow-sm transition-colors">
                    <i class="ri-file-pdf-line"></i> PDF
                </button>
            </div>
        </div>

        
        <div class="flex bg-input-bg p-1 rounded-lg w-full md:w-auto relative ">
            <button onclick="setFilterType('day')" id="btn-day" 
                class="filter-tab flex-1 md:flex-none w-full md:w-20 py-2 md:py-1.5 text-xs font-bold rounded-md transition-all duration-200 shadow-custom bg-card-bg text-primary uppercase tracking-wider">
                <?php echo e(__('messages.day')); ?>

            </button>
            <button onclick="setFilterType('month')" id="btn-month" 
                class="filter-tab flex-1 md:flex-none w-full md:w-20 py-2 md:py-1.5 text-xs font-bold rounded-md transition-all duration-200 text-sidebar-text hover:text-primary hover:bg-card-bg uppercase tracking-wider">
                <?php echo e(__('messages.month')); ?>

            </button>
            <button onclick="setFilterType('year')" id="btn-year" 
                class="filter-tab flex-1 md:flex-none w-full md:w-20 py-2 md:py-1.5 text-xs font-bold rounded-md transition-all duration-200 text-sidebar-text hover:text-primary hover:bg-card-bg uppercase tracking-wider">
                <?php echo e(__('messages.year')); ?>

            </button>
        </div>

        
        <div class="hidden md:block w-px my-1 bg-bor-color"></div>

        
        <div id="filter-inputs" class="flex-1 flex flex-col md:flex-row items-stretch md:items-center justify-between md:justify-start gap-2">
            
            
            <div id="group-day" class="filter-group flex flex-row items-center w-full md:w-auto">
                <div class="flex items-center bg-input-bg px-2 py-2 md:py-1.5 rounded-lg border border-input-border w-full md:w-auto justify-between">
                    
                    <input type="date" id="day-start" 
                           class="bg-transparent border-none text-[11px] md:text-sm font-bold text-sidebar-text focus:ring-0 p-0 cursor-pointer flex-1 w-0 md:w-auto min-w-0 text-center appearance-none placeholder-gray-400" 
                           value="<?php echo e(date('Y-m-d')); ?>" onchange="fetchReport()">
                    
                    <span class="text-gray-400 text-[10px] px-1 shrink-0"><i class="ri-arrow-right-line"></i></span>
                    
                    
                    <input type="date" id="day-end" 
                           class="bg-transparent border-none text-[11px] md:text-sm font-bold text-sidebar-text focus:ring-0 p-0 cursor-pointer flex-1 w-0 md:w-auto min-w-0 text-center appearance-none placeholder-gray-400" 
                           value="<?php echo e(date('Y-m-d')); ?>" onchange="fetchReport()">
                </div>
            </div>

            
            <div id="group-month" class="filter-group hidden flex-row items-center w-full md:w-auto">
                <div class="flex items-center bg-input-bg px-2 py-2 md:py-1.5 rounded-lg border border-input-border w-full md:w-auto justify-between">
                    
                    <input type="month" id="month-start" 
                           class="bg-transparent border-none text-[11px] md:text-sm font-bold text-sidebar-text focus:ring-0 p-0 cursor-pointer flex-1 w-0 md:w-auto min-w-0 text-center appearance-none placeholder-gray-400" 
                           value="<?php echo e(date('Y-m')); ?>" onchange="fetchReport()">
                    
                    <span class="text-gray-400 text-[10px] px-1 shrink-0"><i class="ri-arrow-right-line"></i></span>
                    
                    
                    <input type="month" id="month-end" 
                           class="bg-transparent border-none text-[11px] md:text-sm font-bold text-sidebar-text focus:ring-0 p-0 cursor-pointer flex-1 w-0 md:w-auto min-w-0 text-center appearance-none placeholder-gray-400" 
                           value="<?php echo e(date('Y-m')); ?>" onchange="fetchReport()">
                </div>
            </div>

            
            <div id="group-year" class="filter-group hidden flex-row items-center w-full md:w-auto">
                <div class="flex items-center bg-input-bg px-3 py-2 md:py-1.5 rounded-lg border border-input-border w-full md:w-auto justify-between">
                    <select id="year-start" class="bg-transparent border-none text-xs md:text-sm font-bold text-sidebar-text focus:ring-0 p-0 cursor-pointer w-full md:w-24 text-center" onchange="fetchReport()">
                        <?php for($i = date('Y'); $i >= date('Y') - 5; $i--): ?> <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option> <?php endfor; ?>
                    </select>
                    <span class="text-gray-400 text-xs px-2 shrink-0"><i class="ri-arrow-right-line"></i></span>
                    <select id="year-end" class="bg-transparent border-none text-xs md:text-sm font-bold text-sidebar-text focus:ring-0 p-0 cursor-pointer w-full md:w-24 text-center" onchange="fetchReport()">
                        <?php for($i = date('Y'); $i >= date('Y') - 5; $i--): ?> <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option> <?php endfor; ?>
                    </select>
                </div>
            </div>

            
            <button onclick="triggerReset()" class="hidden md:block ml-2 p-2 rounded-full text-sidebar-text hover:text-primary hover:bg-input-bg transition-all shadow-custom border border-transparent hover:border-bor-color">
                <i class="ri-refresh-line text-lg"></i>
            </button>
        </div>
    </div>
</div><?php /**PATH C:\ZYNX\mikeav2\sale_mi\resources\views/admin/report/sale_report/partials/filters.blade.php ENDPATH**/ ?>