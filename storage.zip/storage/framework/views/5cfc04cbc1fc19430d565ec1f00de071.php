<?php $__env->startSection('title', __('messages.sale_report')); ?>

<?php $__env->startSection('content'); ?>
<div class="w-full h-full px-2 py-2 sm:px-4 sm:py-4" x-data="productManagement()">
    
    
    <?php echo $__env->make('admin.report.sale_report.partials.filters', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <?php echo $__env->make('admin.report.sale_report.partials.summary-cards', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <?php echo $__env->make('admin.report.sale_report.partials.table', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <?php echo $__env->make('admin.report.sale_report.partials.modal-detail', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</div>


<?php echo $__env->make('admin.report.sale_report.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\ZYNX\mikeav2\sale_mi\resources\views/admin/report/sale_report/index.blade.php ENDPATH**/ ?>