<!DOCTYPE html>
<html lang="km">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>វិក្កយបត្រទូទាត់ប្រាក់</title>
    
    
    <link href="https://fonts.googleapis.com/css2?family=Battambang:wght@400;700&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>

    <style>
        /* កំណត់ទំហំក្រដាស Print ឱ្យពេញ (Full Label Margin = 0) */
        @page { 
            margin: 0; 
        }
        
        body { 
            margin: 0; 
            padding: 0; 
            width: 100%;
            background: white; 
            font-family: 'Battambang', cursive !important;
        }
        
        /* កំណត់ទទឹង ១០០% និង Padding ឆ្វេង-ស្តាំ 20px */
        .receipt-paper { 
            width: 100%; 
            margin: 0;
            padding: 5px 10px; /* លើ-ក្រោម 15px, ឆ្វេង-ស្តាំ 20px */
            box-sizing: border-box; 
            color: #000;
        }
        
        /* បន្ទាត់ */
        .dashed-line { 
            border-top: 2px dashed #000; 
            margin: 10px 0; 
        }
        .solid-line { 
            border-top: 2px solid #000; 
            margin: 10px 0; 
        }

        /* តម្រូវសម្រាប់ពេល Print */
        @media print {
            html, body {
                width: 100%;
                margin: 0;
                padding: 0;
            }
            .receipt-paper { 
                width: 100%; 
                padding: 0 20px; /* លើ-ក្រោម 0, ឆ្វេង-ស្តាំ 20px ពេលព្រីន */
                box-shadow: none; 
            }
        }
    </style>
</head>
<body>

    <div id="receipt-print-area" class="receipt-paper">
        
        
        <div class="text-center mb-5">
            <h1 class="text-[34px] font-bold leading-tight mb-2">
                <?php echo e($shop->shop_en ?? ($shop->name ?? 'POS SYSTEM')); ?>

            </h1>
            <p class="text-[20px] leading-tight"><?php echo e($shop->address_en ?? ''); ?></p>
            <?php if(!empty($shop->phone_number)): ?>
                <p class="text-[20px] leading-tight mt-1 font-bold">Tel: <?php echo e($shop->phone_number); ?></p>
            <?php endif; ?>
        </div>

        
        <div class="text-center mb-5">
            <div class="text-[30px] font-bold">វិក្កយបត្រទូទាត់ប្រាក់</div>
        </div>

        
        <div class="text-[22px] mb-4 space-y-2">
            <div class="flex justify-between items-end">
                <span>លេខវិក្កយបត្រ៖</span> 
                <span class="font-bold text-[24px]"><?php echo e($order->invoice_number ?? '---'); ?></span>
            </div>
            <div class="flex justify-between items-end">
                <span>កាលបរិច្ឆេទ៖</span> 
                <span class="font-bold"><?php echo e($order->created_at ? $order->created_at->format('d/m/Y h:i A') : now()->format('d/m/Y h:i A')); ?></span>
            </div>
            <div class="flex justify-between items-end">
                <span>ម៉ោងចូល៖</span> 
                <span class="font-bold"><?php echo e($order->check_in_time ? \Carbon\Carbon::parse($order->check_in_time)->format('h:i A') : '---'); ?></span>
            </div>
            <div class="flex justify-between items-end">
                <span>ម៉ោងចេញ៖</span> 
                <span class="font-bold"><?php echo e(\Carbon\Carbon::parse($order->check_out_time ?? now())->format('h:i A')); ?></span>
            </div>
            <div class="flex justify-between items-end">
                <span>លេខតុ៖</span> 
                <span class="font-bold text-[26px]"><?php echo e($order->table->name ?? 'ទូទៅ'); ?></span>
            </div>
            <!-- <div class="flex justify-between items-end">
                <span>អ្នកគិតលុយ៖</span> 
                <span class="font-bold"><?php echo e($order->user->name ?? (auth()->user()->name ?? 'បុគ្គលិក')); ?></span>
            </div> -->
        </div>

        <div class="solid-line"></div>

        
        <table class="w-full text-[20px] leading-tight">
            <thead>
                <tr class="text-left">
                    <th class="pb-3 font-bold w-[40%]">ឈ្មោះទំនិញ</th>
                    <th class="pb-3 font-bold text-right w-[20%]">តម្លៃ</th>
                    <th class="pb-3 font-bold text-center w-[15%]">ចំនួន</th>
                    <th class="pb-3 font-bold text-right w-[25%]">សរុប(៛)</th>
                </tr>
            </thead>
            <tbody class="align-top">
                
                <tr>
                    <td colspan="4"><div class="dashed-line mt-0 mb-3"></div></td>
                </tr>
                
                <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $qty = $item->quantity;
                        $price = $item->price;
                        $lineTotal = $price * $qty;
                    ?>
                    
                    <tr class="mt-2">
                        
                        <td class="pt-2 pr-1 font-bold text-gray-900 text-[22px]">
                            <?php echo e($item->product->name ?? 'មិនស្គាល់'); ?>

                        </td>
                        
                        <td class="pt-2 text-right font-normal text-[20px] text-gray-800"><?php echo e(number_format($price)); ?></td>
                        
                        <td class="pt-2 text-center font-bold text-[22px]"><?php echo e($qty); ?></td>
                        
                        
                        <td class="pt-2 text-right font-bold text-[22px] tracking-tight"><?php echo e(number_format($lineTotal)); ?></td>
                    </tr>

                    
                    <?php if($item->addons && count($item->addons) > 0): ?>
                        <?php $__currentLoopData = $item->addons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-[18px]">
                                
                                <td class="pl-4 pt-1 text-gray-800">
                                    + <?php echo e($ad->addon->name ?? ($ad->name ?? 'បន្ថែម')); ?> 
                                </td>
                                
                                
                                <td class="text-right pt-1 text-gray-700">
                                    <?php echo e(number_format($ad->price)); ?>

                                </td>
                                
                                
                                <td class="text-center pt-1 text-gray-800 font-bold">
                                    <?php echo e($ad->quantity ?? 1); ?>

                                </td>
                                
                                
                                <td class="text-right pt-1 tracking-tight text-gray-800 font-bold">
                                    <?php echo e(number_format($ad->price * ($ad->quantity ?? 1))); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div class="solid-line mt-4 mb-2"></div>

        
        <div class="text-[24px] mt-2">
            <div class="flex justify-between items-center font-bold py-2">
                <span class="text-[28px]">សរុបទឹកប្រាក់៖</span> 
                <span class="text-[34px] tracking-tight"><?php echo e(number_format($order->total_amount ?? 0)); ?> ៛</span>
            </div>
        </div>

        <div class="solid-line mt-3 mb-4"></div>

        
        <div class="text-center mt-5 pb-5">
            <p class="font-bold text-[26px] mb-2">*** សូមអរគុណ ***</p>
            <p class="text-[20px]">សូមអញ្ជើញមកម្ដងទៀត</p>
        </div>
        
    </div>

</body>
</html><?php /**PATH C:\ZYNX\mikeav2\sale_mi\resources\views/pos/invoice_receipt.blade.php ENDPATH**/ ?>