<div class="bg-card-bg border border-border-color rounded-2xl p-6 shadow-custom transition-all duration-300">
    <h3 class="font-bold text-lg mb-6 flex items-center gap-3 text-gray-800 dark:text-white pb-4 border-b border-border-color">
        <span class="p-2 rounded-lg bg-purple-50 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400">
            <i class="ri-layout-masonry-fill"></i>
        </span>
        <?php echo e(__('messages.layout_structure')); ?>

    </h3>
    
    <?php echo $__env->make('components.color-input', ['label' => __('messages.col_sidebar_bg'), 'key' => 'sidebarBg'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('components.color-input', ['label' => __('messages.col_sidebar_text'), 'key' => 'sidebarText'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="mt-4 pt-4 border-t border-dashed border-gray-200 dark:border-gray-700">
        <p class="text-xs font-bold text-gray-400 uppercase mb-3"><?php echo e(__('messages.sidebar_hover_state')); ?></p>
        <?php echo $__env->make('components.color-input', ['label' => __('messages.col_hover_bg'), 'key' => 'sidebarHoverBg'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('components.color-input', ['label' => __('messages.col_hover_text'), 'key' => 'sidebarHoverText'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    <?php echo $__env->make('components.color-input', ['label' => __('messages.col_header_bg'), 'key' => 'headerBg'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div><?php /**PATH C:\ZYNX\mikeav2\sale_mi\resources\views/admin/theme/layout_structure.blade.php ENDPATH**/ ?>