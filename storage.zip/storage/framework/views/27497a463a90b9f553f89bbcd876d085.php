<div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
    
    
    <div>
        <h1 class="text-xl sm:text-2xl font-bold text-text-color flex items-center gap-2">
            <i class="ri-table-line"></i>
            <?php echo e(__('messages.table_management')); ?>

        </h1>
    </div>

    
    <div class="flex flex-col sm:flex-row items-center gap-3 w-full md:w-auto">

        
        <div x-show="selectedIds.length > 0" x-transition 
             class="flex items-center gap-2 w-full sm:w-auto justify-between bg-primary/10 border border-primary/20 p-2 rounded-xl order-first sm:order-none">
            <span class="text-xs font-bold text-primary px-2" x-text="selectedIds.length + ' <?php echo e(__('messages.selected_items')); ?>'"></span>
            <div class="flex gap-1">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('table-edit')): ?>
                <button @click="startSequentialEdit()" class="h-8 w-8 flex items-center justify-center rounded-lg bg-blue-100 text-blue-600 hover:bg-blue-200 transition"><i class="ri-edit-circle-line"></i></button>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('table-delete')): ?>
                <button @click="confirmBulkDelete()" class="h-8 w-8 flex items-center justify-center rounded-lg bg-red-100 text-red-600 hover:bg-red-200 transition"><i class="ri-delete-bin-line"></i></button>
                <?php endif; ?>
            </div>
        </div>

        
        <div class="flex items-center gap-2 w-full md:w-auto">
            
            
            <div class="relative shrink-0" x-data="{ openCol: false }">
                <button @click="openCol = !openCol" @click.outside="openCol = false" 
                        class="h-[42px] px-3 bg-white dark:bg-gray-800 border border-input-border rounded-xl text-text-color hover:bg-gray-50 dark:hover:bg-gray-700 transition text-sm font-medium shadow-sm flex items-center justify-center gap-2">
                    <i class="ri-layout-column-line text-lg"></i> 
                    <span class="hidden lg:inline"><?php echo e(__('messages.columns')); ?></span>
                </button>
                <div x-show="openCol" class="absolute left-0 mt-2 w-48 bg-white dark:bg-gray-800 border border-border-color rounded-xl shadow-xl z-50 p-2" style="display: none;" x-transition>
                    <div class="space-y-1">
                        <label class="flex items-center gap-2 px-2 py-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded cursor-pointer select-none">
                            <input type="checkbox" x-model="showCols.name" class="rounded text-primary focus:ring-primary border-input-border">
                            <span class="text-sm text-text-color"><?php echo e(__('messages.table_name')); ?></span>
                        </label>
                        <label class="flex items-center gap-2 px-2 py-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded cursor-pointer select-none">
                            <input type="checkbox" x-model="showCols.status" class="rounded text-primary focus:ring-primary border-input-border">
                            <span class="text-sm text-text-color"><?php echo e(__('messages.status')); ?></span>
                        </label>
                        <label class="flex items-center gap-2 px-2 py-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded cursor-pointer select-none">
                            <input type="checkbox" x-model="showCols.created_at" class="rounded text-primary focus:ring-primary border-input-border">
                            <span class="text-sm text-text-color"><?php echo e(__('messages.created_at')); ?></span>
                        </label>
                    </div>
                </div>
            </div>

            
            <div class="relative flex-1 md:w-64">
                <span class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-secondary"><i class="ri-search-line"></i></span>
                <input type="text" x-model="search" @keyup.debounce.500ms="fetchTables()" 
                       class="w-full pl-9 pr-4 py-2.5 rounded-xl border border-input-border bg-white dark:bg-gray-800 text-text-color text-sm shadow-sm outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all" 
                       placeholder="<?php echo e(__('messages.search_placeholder')); ?>">
            </div>

            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('table-create')): ?>
            <button @click="openModal('create')" 
                    class="bg-primary text-white font-bold py-2.5 px-4 md:px-6 rounded-xl shadow-lg shadow-primary/30 hover:opacity-90 flex items-center gap-2 shrink-0 transition-all whitespace-nowrap cursor-pointer">
                <i class="ri-add-circle-line text-xl"></i>
                <span class="md:hidden">Add</span> 
                <span class="hidden md:inline"><?php echo e(__('messages.add_table')); ?></span>
            </button>
            <?php endif; ?>
        </div>

    </div>
</div><?php /**PATH C:\ZYNX\mikeav2\sale_mi\resources\views/admin/table/partials/header.blade.php ENDPATH**/ ?>