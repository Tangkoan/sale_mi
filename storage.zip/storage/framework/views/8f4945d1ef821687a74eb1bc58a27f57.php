<?php $__env->startSection('title', __('messages.menu_management')); ?>

<?php $__env->startSection('content'); ?>
<div class="h-screen w-full bg-[#F6F8FC] dark:bg-[#0f172a] flex flex-col relative overflow-hidden font-sans" x-data="posMenu()" x-cloak>
    
    
    <?php echo $__env->make('pos.menu.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <?php echo $__env->make('pos.menu.product-grid', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <?php echo $__env->make('pos.menu.cart-button', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <?php echo $__env->make('pos.menu.product-modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <?php echo $__env->make('pos.menu.cart-modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</div>


<?php echo $__env->make('pos.menu.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.blank', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\ZYNX\mikeav2\sale_mi\resources\views/pos/menu.blade.php ENDPATH**/ ?>