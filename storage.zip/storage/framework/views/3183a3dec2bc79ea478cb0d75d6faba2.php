<?php $__env->startSection('content'); ?>

<?php $__env->startSection('title', __('messages.user_management')); ?>


<div class="w-full h-full px-2 py-2 sm:px-4 sm:py-4" x-data="userManagement()">
    
    
    <?php echo $__env->make('admin.user.partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <div class="hidden md:block">
        <?php echo $__env->make('admin.user.partials.table', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    
    <div class="md:hidden">
        <?php echo $__env->make('admin.user.partials.mobile_card', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
    
    
    <?php echo $__env->make('admin.user.partials.pagination', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <?php echo $__env->make('admin.user.partials.modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</div>

<script>
    function userManagement() {
        return {
            users: [],
            // ⚠️ Ensure $roles is passed from controller
            roles: <?php echo json_encode($roles ?? [], 15, 512) ?>, 
            
            search: '',
            perPage: '10',
            currentPage: 1, 
            pagination: { last_page: 1, total: 0 }, 
            
            isModalOpen: false,
            editMode: false,
            isLoading: false,
            selectedIds: [],
            selectAll: false,

            // Column Config (Removed Email)
            showCols: JSON.parse(localStorage.getItem('user_table_cols')) || { 
                role: true, 
                created_at: true 
            },

            isSequenceMode: false,
            sequenceQueue: [],
            currentSeqIndex: 0,

            form: { id: null, name: '', role: '', password: '', pin: '' },
            errors: {},

            init() { 
                this.$watch('showCols', (value) => { localStorage.setItem('user_table_cols', JSON.stringify(value)); });
                this.fetchUsers(); 
            },

            // Smart Pagination Logic
            get visiblePages() {
                const total = this.pagination.last_page;
                const current = this.currentPage;
                const delta = 2;
                let pages = [];
                if (total <= 7) { for (let i = 1; i <= total; i++) pages.push(i); return pages; }
                pages.push(1);
                if (current > delta + 2) pages.push('...');
                let start = Math.max(2, current - delta);
                let end = Math.min(total - 1, current + delta);
                for (let i = start; i <= end; i++) pages.push(i);
                if (current < total - delta - 1) pages.push('...');
                if (total > 1) pages.push(total);
                return pages;
            },

            async fetchUsers() {
                let url = "<?php echo e(route('admin.users.fetch')); ?>";
                const params = new URLSearchParams({
                    keyword: this.search,
                    per_page: this.perPage,
                    page: this.currentPage
                });
                
                this.isLoading = true;
                try {
                    const response = await fetch(`${url}?${params}`);
                    const data = await response.json();
                    this.users = data.data;
                    this.pagination = data; 
                    this.currentPage = data.current_page;
                    this.selectAll = false;
                } catch (error) { console.error(error); } 
                finally { this.isLoading = false; }
            },

            gotoPage(page) { if(page === '...') return; this.currentPage = page; this.fetchUsers(); },
            
            toggleSelectAll() {
                this.selectedIds = this.selectAll ? this.users.map(u => u.id) : [];
            },

            // ================= SEQUENTIAL EDIT =================
            startSequentialEdit() {
                const selectedIdsString = this.selectedIds.map(id => String(id));
                this.sequenceQueue = this.users.filter(item => selectedIdsString.includes(String(item.id)));
                
                if (this.sequenceQueue.length === 0) {
                    window.dispatchEvent(new CustomEvent('notify', { detail: { type: 'error', message: "<?php echo e(__('messages.select_users_first')); ?>" } })); 
                    return;
                }

                this.isSequenceMode = true;
                this.currentSeqIndex = 0;
                this.loadUserToForm(this.sequenceQueue[0]);
                this.isModalOpen = true;
            },

            nextInSequence() {
                this.currentSeqIndex++;
                if (this.currentSeqIndex < this.sequenceQueue.length) {
                    this.loadUserToForm(this.sequenceQueue[this.currentSeqIndex]);
                } else {
                    this.closeModal(true); 
                    window.dispatchEvent(new CustomEvent('notify', { detail: { type: 'success', message: "<?php echo e(__('messages.all_users_updated')); ?>" } }));
                }
            },

            loadUserToForm(user) {
                this.editMode = true;
                this.errors = {};
                this.form = { 
                    id: user.id, 
                    name: user.name, 
                    role: user.roles.length > 0 ? user.roles[0].name : '',
                    password: '', // Reset password field
                    pin: ''
                };
            },

            // ================= MODAL & FORM =================
            openModal(mode, item = null) {
                this.isSequenceMode = false;
                this.isModalOpen = true;
                this.errors = {};
                
                if (mode === 'edit') {
                    this.loadUserToForm(item);
                } else {
                    this.editMode = false;
                    this.form = { id: null, name: '', role: '', password: '',pin: '' };
                }
            },

            closeModal(force = false) {
                 if (!force && this.isSequenceMode && !confirm("<?php echo e(__('messages.confirm_stop_sequence')); ?>")) return;
                this.isModalOpen = false;
                this.isSequenceMode = false;
                this.selectedIds = [];
                this.selectAll = false;
                this.fetchUsers(); 
            },

            async submitForm() {
                this.isLoading = true;
                this.errors = {};
                
                let url = "<?php echo e(route('admin.users.store')); ?>";
                let method = 'POST';

                if (this.editMode) {
                    url = `/admin/users/${this.form.id}`;
                    method = 'PUT';
                }

                try {
                    const response = await fetch(url, {
                        method: method,
                        headers: { 
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content') 
                        },
                        body: JSON.stringify(this.form)
                    });
                    
                    const data = await response.json();

                    if (!response.ok) {
                        if (response.status === 422) {
                            this.errors = data.errors;
                            window.dispatchEvent(new CustomEvent('notify', { detail: { type: 'error', message: "<?php echo e(__('messages.fix_errors')); ?>" } }));
                        } else {
                            window.dispatchEvent(new CustomEvent('notify', { detail: { type: 'error', message: data.message || 'Error' } }));
                        }
                    } else {
                        window.dispatchEvent(new CustomEvent('notify', { detail: { type: 'success', message: data.message } }));
                        
                        if (this.isSequenceMode) {
                            this.nextInSequence();
                        } else {
                            this.closeModal();
                            this.fetchUsers();
                        }
                    }
                } catch (error) { console.error(error); } 
                finally { this.isLoading = false; }
            },
            
            // ================= DELETE =================
            async confirmDelete(id) {
                if(typeof askConfirm !== 'undefined') {
                    askConfirm(async () => { await this.performDelete([id]); });
                } else if(confirm("Are you sure?")) {
                    await this.performDelete([id]);
                }
            },

            async confirmBulkDelete() {
                if (this.selectedIds.length === 0) return;
                if(typeof askConfirm !== 'undefined') {
                    askConfirm(async () => { await this.performDelete(this.selectedIds, true); });
                } else if(confirm("Delete selected items?")) {
                    await this.performDelete(this.selectedIds, true);
                }
            },

            async performDelete(ids, isBulk = false) {
                let url = isBulk ? "<?php echo e(route('admin.users.bulk_delete')); ?>" : `/admin/users/${ids[0]}`;
                let method = isBulk ? 'POST' : 'DELETE';
                let body = isBulk ? JSON.stringify({ ids: ids }) : null;

                try {
                    const response = await fetch(url, {
                        method: method,
                        headers: { 
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content') 
                        },
                        body: body
                    });
                    
                    const data = await response.json();

                    if(response.ok) {
                        this.selectedIds = [];
                        this.selectAll = false;
                        this.fetchUsers();
                        window.dispatchEvent(new CustomEvent('notify', { detail: { type: 'success', message: data.message || "<?php echo e(__('messages.delete_success')); ?>" } }));
                    } else {
                        window.dispatchEvent(new CustomEvent('notify', { detail: { type: 'error', message: data.message || "<?php echo e(__('messages.delete_fail')); ?>" } }));
                    }
                } catch(e) { console.error(e); }
            }
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\ZYNX\mikeav2\sale_mi\resources\views/admin/user/user_list.blade.php ENDPATH**/ ?>