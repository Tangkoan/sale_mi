<?php $__env->startSection('title', __('messages.shop_management')); ?>


<?php $__env->startSection('content'); ?>


<?php if($errors->any()): ?>
    <div class="mb-6 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-xl relative shadow-sm" role="alert">
        <strong class="font-bold"><i class="ri-error-warning-line mr-1"></i> Error!</strong>
        <ul class="mt-1 list-disc list-inside text-sm">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<div class="min-h-screen py-8 bg-page-bg" x-data="shopForm()">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        <form action="<?php echo e(route('admin.shop_info.save')); ?>" method="POST" enctype="multipart/form-data" class="relative">
            <?php echo csrf_field(); ?>

            
            <?php echo $__env->make('admin.shop_info.partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <div class="grid grid-cols-1 xl:grid-cols-12 gap-8">
                
                
                <div class="xl:col-span-8 space-y-8">
                    <?php echo $__env->make('admin.shop_info.partials.english_details', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php echo $__env->make('admin.shop_info.partials.khmer_details', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>

                
                <div class="xl:col-span-4 space-y-8">
                    <?php echo $__env->make('admin.shop_info.partials.general_settings', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php echo $__env->make('admin.shop_info.partials.branding', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>

            </div>
        </form>
    </div>
</div>

<script>
    function shopForm() {
        return {
            logoPreview: '<?php echo e($shop->logo ? asset("storage/".$shop->logo) : null); ?>',
            favPreview: '<?php echo e($shop->fav ? asset("storage/".$shop->fav) : null); ?>',

            updatePreview(event, previewName) {
                const file = event.target.files[0];
                if (!file) return;
                const reader = new FileReader();
                reader.onload = (e) => { this[previewName] = e.target.result; };
                reader.readAsDataURL(file);
            }
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\ZYNX\mikeav2\sale_mi\resources\views/admin/shop_info/form.blade.php ENDPATH**/ ?>