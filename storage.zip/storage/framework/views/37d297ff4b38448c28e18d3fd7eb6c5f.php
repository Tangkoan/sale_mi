<?php $__env->startSection('title', __('messages.pos_management')); ?>


<?php $__env->startSection('content'); ?>
<div class="h-screen w-full bg-[#F6F8FC] dark:bg-[#0f172a] flex flex-col font-sans relative overflow-hidden" x-data="posTables()">
    
    
    <?php echo $__env->make('pos.table.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    

    
    <div x-show="isLoading && tables.length === 0" class="flex-1 flex flex-col items-center justify-center text-gray-400">
        <i class="ri-loader-4-line text-5xl animate-spin mb-4 text-primary"></i>
        <p>Loading...</p>
    </div>

    
    <?php echo $__env->make('pos.table.grid', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <?php echo $__env->make('pos.table.checkout-modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <?php echo $__env->make('pos.table.receipt', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</div>


<?php echo $__env->make('pos.table.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('pos.table.styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.blank', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\ZYNX\mikeav2\sale_mi\resources\views/pos/tables.blade.php ENDPATH**/ ?>