<!DOCTYPE html>
<html lang="km">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kitchen Receipt</title>
    
    
    <link href="https://fonts.googleapis.com/css2?family=Battambang:wght@400;700;900&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>

    <style>
        /* កំណត់ទំហំក្រដាស Print ឱ្យពេញ */
        @page { 
            margin: 0; 
        }
        
        /* ប្រើ fit-content ដើម្បីកាត់ផ្ដាច់ត្រឹមចុងអក្សរ កុំឲ្យសល់ក្រដាស */
        html, body { 
            margin: 0; 
            padding: 0; 
            width: 100%;
            height: fit-content; 
            background: white; 
            font-family: 'Battambang', cursive !important; 
            color: #000;
        }
        
        .receipt-paper { 
            width: 100%; 
            margin: 0;
            padding: 20px 15px; /* គម្លាត 20px លើ-ក្រោម និង 15px ឆ្វេង-ស្តាំ */
            box-sizing: border-box; 
            overflow: hidden;
        }
        
        /* បន្ទាត់ */
        .solid-line { 
            border-top: 2px solid #000; 
            margin: 12px 0; 
        }

        /* តម្រូវសម្រាប់ពេល Print */
        @media print {
            html, body {
                height: max-content;
            }
            .receipt-paper { 
                padding: 20px 15px; /* រក្សាគម្លាត 20px ដដែលពេលព្រីន */
            }
        }
    </style>
</head>
<body>

    <div id="receipt-print-area" class="receipt-paper">
        
        
        <div class="text-center mb-4">
            <h1 class="text-[34px] font-black uppercase leading-tight tracking-wide border-2 border-black inline-block px-4 py-1 rounded-lg">
                <?php echo e($printerInfo->name ?? 'ORDER'); ?>

            </h1>
        </div>

        
        <div class="text-[22px] mb-3 space-y-2">
            <div class="flex justify-between items-end">
                <span class="font-bold text-[24px]">តុ (Table) ៖</span> 
                <span class="font-black text-[32px]"><?php echo e($tableName); ?></span>
            </div>
            <div class="flex justify-between items-end text-[20px]">
                <span>ម៉ោង (Time) ៖</span> 
                <span class="font-bold"><?php echo e(now()->format('d/m/Y h:i A')); ?></span>
            </div>
        </div>

        <div class="solid-line"></div>

        
        <table class="w-full text-[24px] leading-tight mt-2">
            <tbody class="align-top">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-b-[2px] border-dotted border-gray-500 last:border-b-0">
                        
                        <td class="py-3 w-full">
                            
                            <div class="font-bold text-[26px] text-gray-900 leading-tight">
                                <span><?php echo e($item->product->name ?? 'Unknown'); ?></span>
                                <span class="font-black text-[28px] ml-[10px]">(*<?php echo e($item->quantity); ?>)</span>
                            </div>
                            
                            
                            <?php if($item->note): ?>
                                <div class="text-[20px] italic text-gray-800 mt-2 border-l-[4px] border-black pl-3 py-1 bg-gray-50">
                                    📝 ចំណាំ: <?php echo e($item->note); ?>

                                </div>
                            <?php endif; ?>

                            
                            <?php if($item->addons && $item->addons->count() > 0): ?>
                                <div class="mt-2 space-y-1">
                                    <?php $__currentLoopData = $item->addons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $addonRow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="text-[20px] text-gray-800 pl-2">
                                            <span>➕ <?php echo e($addonRow->addon->name ?? 'Extra'); ?></span>
                                            <span class="font-bold text-[22px] ml-[10px]">(*<?php echo e($addonRow->quantity); ?>)</span>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>
                        </td>
                        
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div class="solid-line mt-2 mb-2"></div>
        
        
        
        <div class="text-center mt-2">
            <p class="font-black text-[22px]">*** សូមរៀបចំមុខម្ហូបខាងលើ ***</p>
        </div>

    </div>

</body>
</html><?php /**PATH C:\ZYNX\mikeav2\sale_mi\resources\views/pos/kitchen_receipt.blade.php ENDPATH**/ ?>