<?php $__env->startSection('title', __('messages.theme_management')); ?>

<style>
    /* Mobile (Default) */
    #actionBar { left: 1.5rem; right: 1.5rem; transition: left 0.3s cubic-bezier(0.4, 0, 0.2, 1); }
    /* Desktop */
    @media (min-width: 768px) {
        #actionBar { left: 19rem; right: 2.5rem; }
        body.collapsed #actionBar { left: 6rem; }
    }
</style>

<?php $__env->startSection('content'); ?>
<div class="max-w-5xl mx-auto pb-32" x-data="{ activeTab: $store.theme.darkMode ? 'dark' : 'light' }"
    x-effect="activeTab = $store.theme.darkMode ? 'dark' : 'light'">

    
    <?php echo $__env->make('admin.theme.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

        
        <?php echo $__env->make('admin.theme.brand_identity', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        
        <?php echo $__env->make('admin.theme.layout_structure', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        
        <?php echo $__env->make('admin.theme.content_forms', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    </div>

    
    <?php echo $__env->make('admin.theme.action_bar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\ZYNX\mikeav2\sale_mi\resources\views/admin/theme.blade.php ENDPATH**/ ?>