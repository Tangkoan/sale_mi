<?php $__empty_1 = true; $__currentLoopData = $topProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="flex items-center gap-3 animate-fade-in group">
        
        <div class="w-10 h-10 rounded-lg bg-input-bg border border-bor-color flex items-center justify-center flex-shrink-0 overflow-hidden">
            <?php if($item->product->image ?? false): ?>
                <img src="<?php echo e(asset('storage/'.$item->product->image)); ?>" class="w-full h-full object-cover">
            <?php else: ?>
                <i class="ri-image-line text-gray-400"></i>
            <?php endif; ?>
        </div>
        
        <div class="flex-1 min-w-0">
            <div class="flex justify-between mb-1">
                
                <h4 class="text-sm font-bold text-sidebar-text truncate w-32 group-hover:text-primary transition-colors">
                    <?php echo e($item->product->name ?? __('messages.unknown_product')); ?>

                </h4>
                
                
                <span class="text-sm font-bold text-sidebar-text">
                    <?php echo e(number_format($item->total_revenue, 0)); ?> ៛
                </span>
            </div>
            
            
            <div class="w-full bg-input-bg rounded-full h-1.5 relative overflow-hidden">
                <div class="absolute left-0 top-0 bottom-0 rounded-full 
                    <?php echo e($index == 0 ? 'bg-amber-400' : ($index == 1 ? 'bg-gray-400' : ($index == 2 ? 'bg-orange-400' : 'bg-blue-400'))); ?>" 
                    style="width: <?php echo e($maxProductSales > 0 ? ($item->total_revenue / $maxProductSales) * 100 : 0); ?>%"></div>
            </div>
            
            
            <div class="text-[10px] text-gray-400 mt-1">
                <?php echo e(number_format($item->total_qty)); ?> <?php echo e(__('messages.units_sold')); ?>

            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    
    <div class="text-center py-10 text-gray-400">
        <i class="ri-inbox-line text-4xl opacity-30 mb-2 block"></i>
        <?php echo e(__('messages.no_data_available')); ?>

    </div>
<?php endif; ?><?php /**PATH C:\ZYNX\mikeav2\sale_mi\resources\views/admin/dashboard/partials/top_products.blade.php ENDPATH**/ ?>